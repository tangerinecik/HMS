<script>
export default {}
</script>
<template>
  <div
    class="fixed-top fixed-bottom fixed d-flex justify-content-center align-items-center"
    style="background: rgba(255, 255, 255, 0.8)"
  >
    <div class="spinner-border" style="width: 80px; height: 80px" role="status"></div>
  </div>
</template>
